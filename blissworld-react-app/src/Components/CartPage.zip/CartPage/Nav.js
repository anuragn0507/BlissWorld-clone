import React from "react";
import "./stylee.css";

function Nav() {
  return (
    <div className="nav">
      <div></div>
    </div>
  );
}

export default Nav;
