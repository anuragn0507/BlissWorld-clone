import React from "react";

function orderconfirm() {
  return (
    <div style={{ width: "100%", height: "100%" }}>
      <img
        src="https://thumbs.gfycat.com/GracefulImpishFlea-size_restricted.gif"
        style={{ width: "100%", height: "100%" }}
      />
    </div>
  );
}

export default orderconfirm;
